import { showLoading } from 'common.js';

module.exports = {
  wxGet: function (url) {
    return showLoading().then(() => {
      return new Promise((resolve, reject) => {
        wx.request({
          url: url,
          method: 'GET',
          data: {},
          header: {
            'Accept': 'application/json',
            'token': wx.getStorageSync('token'),
            'type': wx.getStorageSync('type')
          },
          success: function (res) {
            wx.hideLoading();
            resolve(res);
          },
          error: function (res) {
            wx.hideLoading();
            if (reject) reject(res);
          }
        })
      });
    });
  },
  wxPost: function (url, data) {
    return showLoading().then(() => {
      return new Promise((resolve, reject) => {
        wx.request({
          url: url,
          method: 'POST',
          data: data,
          header: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'token': wx.getStorageSync('token'),
            'type': wx.getStorageSync('type')
          },
          success: function (res) {
            wx.hideLoading();
            resolve(res);
          },
          error: function (res) {
            wx.hideLoading();
            if (reject) reject(res);
          }
        })
      });
    });
  },
  uploadFile: function (url, formData, uploadFile) {
    return showLoading().then(() => {
      return new Promise((resolve, reject) => {
        wx.uploadFile({
          url: url,
          filePath: uploadFile,
          name: 'file',
          formData: formData,
          header: {
            'content-type': 'multipart/form-data',
            'token': wx.getStorageSync('token'),
            'type': wx.getStorageSync('type')
          },
          success: function (res) {
            wx.hideLoading();
            resolve(res);
          },
          fail: function (res) {
            wx.hideLoading();
            if (reject) reject(res);
          }
        });
      });
    });
  }
}
