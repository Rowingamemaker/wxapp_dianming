module.exports = {
  switchTab: function (url) {
    wx.switchTab({
      url: url
    })
  },
  navigateTo: function (url) {
    wx.navigateTo({
      url: url
    })
  },
  redirectTo: function (url) {
    wx.redirectTo({
      url: url
    })
  },
  reLaunch: function (url) {
    wx.reLaunch({
      url: url
    })
  },
  showLoading: function (obj) {
    return new Promise((resolve, reject) => {
      wx.showLoading({
        title: obj && obj.title || "加载中...",
        mask: true,
        success: (e) => {
          resolve(e);
        },
        fail: (e) => {
          wx.hideLoading();
        }
      });
    });
  },
  showLoading2: function (title) {
    return new Promise((resolve) => {
      wx.showLoading({
        title: title || "加载中...",
        mask: true,
        success: (e) => {
          resolve(e);
        },
        fail: (e) => {
          wx.hideLoading();
        }
      });
    });
  },
  showModal: function (obj) {
    wx.showModal({
      title: obj.title || "请求失败！",
      content: obj.content || "",
      showCancel: obj.showCancel || false,
      cancelText: obj.cancelText || "",
      cancelColor: obj.cancelColor || "#000",
      confirmText: obj.confirmText || "返回",
      confirmColor: obj.confirmColor || "#000",
      success: (res) => {
        if (obj.success) obj.success(res);
      },
      fail: () => {
        if (obj.fail) obj.success();
      }
    });
  },
  showToast: function (obj) {
    if (typeof (obj) === "undefined") obj = {};
    wx.showToast({
      title: obj.title || "亲~没有数据了"
    })
  },
  showToast1: function (title, type) {
    wx.showToast({
      title: title,
      icon: type,
      mask: true
    });
    return true;
  },
  login: function () {
    return new Promise(resolve => {
      wx.login({
        success: ({ code = "" }) => {
          resolve(code);
        }
      });
    });
  },
  getLocation: function () {
    return new Promise(resolve => {
      wx.getLocation({
        success: res => {
          resolve(res);
        },
        fail: res => {
          resolve({});
        }
      });
    });
  },
  chooseLocation: function () {
    return new Promise(resolve => {
      wx.chooseLocation({
        success: res => {
          resolve(res);
        },
        fail: res => {
          resolve({});
        }
      });
    });
  },
  onShareAppMessage: function ({ title = "城院点名", path = "/pages/index/index" }) {
    return {
      title: title,
      path: path,
      success: function (res) {
        // 转发成功
      },
      fail: function (res) {
        showToast("转发失败");
      }
    }
  }
}