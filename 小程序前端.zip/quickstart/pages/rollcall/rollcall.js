var bmap = require('../../utils/bmap-wx.min.js');
// var api = require('../../api.js');
import { signIn } from '../../api.js';
var app = getApp();
Page({
  data: {
    courses: [],
    courseNameArr: []
  },
  //学生身份签到
  signIn: function () {
    signIn();
    //获取位置
    // wx.getLocation({
    //   altitude: true,
    //   success: function (res) {
    //     console.log(res);
    //     wx.request({
    //       url: 'http://api.map.baidu.com/geocoder/v2/?ak=kwb5tspgdNBF5GRQ6UyR17zFqFrdLXRc&location=' + res.latitude + ',' + res.longitude + '&output=json&coordtype=wgs84ll',
    //       header: {
    //         'Content-Type': 'application/json'
    //       },
    //       method: 'GET',
    //       dataType: 'json',
    //       success: function (res) {
    //         console.log(res);
    //         var formatted_address = res.data.result.formatted_address;
    //         var sematic_description = res.data.result.sematic_description;
    //         console.log(formatted_address)
    //         wx.request({
    //           url: api.default.signInAdd,
    //           data: {
    //             'sematic_description': sematic_description,
    //             'formatted_address': formatted_address
    //           },
    //           header: {
    //             'Content-Type': 'application/json'
    //           },
    //           method: 'GET',
    //           success: function (res) {
    //               //添加成功
    //               if(res.data.code==1){
    //                 wx.showToast({
    //                   icon: 'success',
    //                   title: '签到成功',
    //                   mask: true
    //                 });
    //               }else if(res.data.code==-1){
    //                 wx.showToast({
    //                   icon: 'fail',
    //                   title: '签到失败',
    //                   mask: true
    //                 });
    //               }
    //           },
    //         })
    //       },
    //       fail: function (res) { },
    //       complete: function (res) { },
    //     })
    // },
    // fail: function (res) { },
    // complete: function (res) { },
    // })
  },
  onLoad: function (options) {
    var that = this;
    var BMap = new bmap.BMapWX({
      ak: 'kwb5tspgdNBF5GRQ6UyR17zFqFrdLXRc'
    });
    var fail = function (data) {
      console.log(data)
    };
    var success = function (data) {
      console.log(data);
      wxMarkerData = data.wxMarkerData;
      that.setData({
        markers: wxMarkerData
      });
      that.setData({
        latitude: wxMarkerData[0].latitude
      });
      that.setData({
        longitude: wxMarkerData[0].longitude
      });
    }
  },
  onReady: function () {
    // 页面渲染完成
  },
  onShow: function () {
    // 页面显示
  },
  onHide: function () {
    // 页面隐藏
  },
  onUnload: function () {
    // 页面关闭
  }
})