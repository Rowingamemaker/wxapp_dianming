// pages/selectroom/selectroom.js
import { $wuxDialog, $wuxLoading } from '../../components/wux';
import { getRooms, getStudents, delRoom, updateRoomName, searchRoom } from '../../api.js';
import { navigateTo } from '../../utils/common.js';
let types = wx.getStorageSync('type');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    rooms: [],//所有教室
    left: 0,//用于用户点击删除以后 自动切换回去一个item  即教室名
    types: 1,//学生和老师的区别
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const wuxLoading = (text) => {
      $wuxLoading.show({
        text: text,
      })
    };
    var pages = this;
    //获取该老师的教师号
    if (types == 1) {
      getRooms().then(res => {
        console.log(res);
        //获取成功
        if (res.data.code == 1) {
          pages.setData({
            rooms: res.data.data.data
          })
        } else if (res.data.code == 0) {
          //教室已存在 询问是否直接进入教室
          let room_id = res.data.data;
        }
      })
      //学生进入教室
    } else if (types == 0) {
      var room_id = options.room_id;
      var data = {
        'room_id': room_id
      };
      searchRoom(data).then(res => {
        console.log('搜索教室');
        console.log(res);
        if (res.data.code == 1) {
          pages.setData({
            rooms: res.data.data,
            types: 0,
          })
        }
      });
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {


  },
  //进入房间  
  enterRoom: function (e) {
    // console.log(e);
    //这个id是class_room表里的主键
    var room_id = e.currentTarget.dataset.id;
    var data = {
      'id': room_id
    };
    navigateTo('../room/room?room_id=' + room_id);

  },
  //教室删除教室
  delRoom: function (e) {
    var id = e.currentTarget.dataset.id;
    var pages = this;
    delRoom({ 'id': id }).then(res => {
      console.log(res);
      pages.setData({
        rooms: res.data.data.data,
        left: 0
      })
    });
  },
  updateRoomName: function (e) {
    console.log(e);
    var id = e.currentTarget.dataset.id;
    var pages = this;
    const alert = (content) => {
      $wuxDialog.alert({
        title: '提示',
        content: content,
        onConfirm(e) {
          // if (content == '修改教室名成功') {
          //   navigateTo('../room/room?id=' + id)
          // }
        }
      })
    }
    $wuxDialog.prompt({
      content: '提示',
      fieldtype: 'number',
      password: 0,
      defaultText: '',
      placeholder: '请输入改名教室编号',
      maxlength: 20,
      onConfirm(e) {
        console.log(e);
        const value = pages.data.$wux.dialog.prompt.response
        let data = {
          'room_id': value,
          'id': id
        };
        updateRoomName(data).then(res => {
          console.log(res);
          let content = res.data.msg
          alert(content)
        })
      },
      //点击取消
      onCancel: function (e) {
        //复位
        pages.setData({
          left: 0
        })
      }
    })

  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})