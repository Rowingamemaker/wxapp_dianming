import { $wuxDialog } from '../../components/wux';
import { createRoom, searchRoom } from '../../api.js';
import { navigateTo } from '../../utils/common.js';
let types = wx.getStorageSync('type');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    timeStart: '08:00',
    timeEnd: '09:35',
    weekdays: [
      { name: '周一', value: '周一' },
      { name: '周二', value: '周二' },
      { name: '周三', value: '周三' },
      { name: '周四', value: '周四' },
      { name: '周五', value: '周五' },
      { name: '周六', value: '周六' },
      { name: '周日', value: '周日' },
    ],
    about: false,
    isStudent: false//是否是学生
  },
  //创建教室
  prompt() {
    const that = this
    let id = '';
    var room_id='';
    const alert = (content) => {
      $wuxDialog.alert({
        title: '提示',
        content: content,
        onConfirm(e) {
          if (content == '教室创建成功') {
            navigateTo('../select/select?id=' + id + '&room_id=' + room_id);
          }
        }
      })
    };
    $wuxDialog.prompt({
      content: '提示',
      fieldtype: 'text',
      password: 0,
      defaultText: '',
      placeholder: '请输入教室编号',
      maxlength: 10,
      xuesheng:true,
      onConfirm(e) {
        room_id = that.data.$wux.dialog.prompt.response;
        var total_number = that.data.$wux.dialog.prompt.response1;
        var data = {
          'room_id': room_id,
          'total_number': total_number
        };
        createRoom(data).then(res => {
          console.log('创建教室');
          console.log(res);
          let content = res.data.msg;
          id = res.data.data;
          alert(content);
        });
      },
    })
  },
  //进入教室
  prompt1() {
    const that = this
    let room_id = '';
    const alert = (content) => {
      $wuxDialog.alert({
        title: '提示',
        content: content,
        onConfirm(e) {
          if (content == '教室搜索成功') {
            navigateTo('../selectroom/selectroom?room_id=' + room_id);
          }
        }
      })
    };
    $wuxDialog.prompt({
      content: '提示',
      fieldtype: 'text',
      password: 0,
      defaultText: '',
      placeholder: '请输入教室编号,支持模糊搜索',
      maxlength: 11,
      xuesheng:false,
      onConfirm(e) {
        room_id = that.data.$wux.dialog.prompt.response;
        var data = {
          'room_id': room_id
        };
        searchRoom(data).then(res => {
          console.log('搜索教室');
          console.log(res);
          if (res.data.code == 1) {
            let content = res.data.msg;
            alert(content);
          }else if(res.data.code==-1){
            let content = res.data.msg;
            alert(content);
          }
        });
      },
    })
  },
  showToast() {
    let $toast = this.selectComponent(".J_toast");
    $toast && $toast.show();
  },
  showToast() {
    let $toast = this.selectComponent(".J_toast");
    $toast && $toast.show();
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var scene = decodeURIComponent(options.scene);
    console.log(scene)
    var pages = this;
    //学生
    if (types == 0) {
      pages.setData({
        isStudent: true
      })
    }
    wx.showToast({
      icon: 'loading',
      title: '初始化页面...',
      mask: true
    });
  },
  about: function (e) {
    console.log(e)
    this.setData({
      about: true
    })
  },
  hide: function () {
    this.setData({
      about: false
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})