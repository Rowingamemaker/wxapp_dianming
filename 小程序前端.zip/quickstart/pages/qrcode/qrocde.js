// pages/qrcode/qrocde.js
import { getQrcode, selectSignInType } from '../../api.js';

Page({

  /**
   * 页面的初始数据
   */
  data: {
    qrcode: '',
    hidden: false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options);
    //id:教室的id
    var data = { 'id': options.id, 'sign_in_type': 0 };
    var pages = this;
    wx.setNavigationBarTitle({
      title: options.room_id,
    })
    selectSignInType(data).then(res => {
      // 请求成功,返回二维码url
      if (res != '' && res.data.code == 1) {
        pages.setData({
          hidden: true,
          qrcode: res.data.data
        })
      }
    });
  },
  //保存二维码
  saveQrcode: function (e) {
    var qrcode = this.data.qrcode;
    // wx.downloadFile({
    //   url: qrcode, //仅为示例，并非真实的资源
    //   success: function (res) {
    //     console.log(res);
    //     // 只要服务器有响应数据，就会把响应内容写入文件并进入 success 回调，业务需要自行判断是否下载到了想要的内容
    //     // if (res.statusCode === 200) {
    //     //   wx.playVoice({
    //     //     filePath: res.tempFilePath
    //     //   })
    //     // }
    //   }
    // })
    // console.log('保存二维码')
    wx.previewImage({
      urls: [qrcode],
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
    // var qrcode = this.data.qrcode;
    // wx.saveImageToPhotosAlbum({
    //   filePath: qrcode,
    //   success: function (res) {
    //     console.log(res)
    //   },
    //   fail: function (res) {
    //     console.log(res)
    //   },
    //   complete: function (res) { },
    // })
  },
  /**
 * 生命周期函数--监听页面初次渲染完成
 */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})