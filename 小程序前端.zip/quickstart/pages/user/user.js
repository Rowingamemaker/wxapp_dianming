var app = getApp()
Page({
  data: {
    motto: 'Hello World',
    userInfo: {
      avatarUrl:'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKg9OTmKEnwwfMznoJUWTwnDW2zYyHsYntqZBEGTTNWd88M8EP6NHvC1DD9KSRutd4zYJTXdkkBwA/132',
      nickName:'醒了吗'
    }
  },
  onLoad: function () {
    console.log('onLoad')
    var that = this
    //调用应用实例的方法获取全局数据  
    app.getUserInfo(function (userInfo) {
      //更新数据  
      that.setData({
        userInfo: userInfo
      })
    })
  },
  onShareAppMessage:function(){
    
  },
  enterRoom:function(){
    
  }
})  