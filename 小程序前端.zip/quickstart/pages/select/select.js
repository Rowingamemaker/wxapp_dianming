// pages/select/select.js
import { navigateTo, chooseLocation, showToast1 } from '../../utils/common.js';
import { getQrcode, roomAddress, randomStudent, randomPassStudent } from '../../api.js';
import { $wuxDialog } from '../../components/wux';

let types = wx.getStorageSync('type')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    qrcode: '',//二维码链接地址
    id: '',//房间id
    about: false,
    student_number: 0,//总学生数
    random: 0,//随机生成的数字
    randomCount: 0,//随机次数
    room_id: '',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options);
    var pages = this;
    //id:房间号
    pages.setData({
      id: options.id,
      room_id: options.room_id
    });
  },
  // 0:二维码 1:地址位置 3:蓝牙 4:随机
  selectSignIn(e) {
    console.log(e)
    const alert = (content) => {
      $wuxDialog.alert({
        title: '提示',
        content: content,
        onConfirm(e) {
          if (content == '教室创建成功') {
            navigateTo('../select/select?id=' + id);
          }
          if (content == '腾讯地图请求成功') {
            navigateTo('../room/room?id=' + id);
          }
        }
      })
    }
    var pages = this;
    var SignInType = e.currentTarget.dataset.signintype
    var id = pages.data.id;//这是教室在数据库对应的id
    var room_id = pages.data.room_id;
    //二维码
    if (SignInType == 0) {
      // var data = { 'id': pages.data.id};
      // getQrcode(data).then(res => {
      //   console.log(res);
      //   // pages.setData({
      //   //   qrcode: res.data
      //   // })
      // })
      let url = '../qrcode/qrocde?id=' + id + '&room_id=' + room_id;
      navigateTo(url);
      //地理位置
    } else if (SignInType == 1) {
      //选择地址
      chooseLocation().then(res => {
        var data = {
          'id': id,
          'latitude': res.latitude,
          'longitude': res.longitude,
        };
        //post传输给后端
        roomAddress(data).then(res => {
          console.log(res);
          if(res.data.code==1){
            alert(res.data.msg);
          }
        })
      });
      //蓝牙
    } else if (SignInType == 2) {

      //随机
    } else if (SignInType == 3) {
      $wuxDialog.prompt({
        content: '提示',
        fieldtype: 'number',
        password: 0,
        defaultText: '',
        placeholder: '请输入学生人数',
        maxlength: 3,
        onConfirm(e) {
          var studentNumber = pages.data.$wux.dialog.prompt.response;
          var random = Math.ceil(Math.random() * studentNumber);//随机数
          var randomCount = 0;
          console.log(studentNumber)
          // setInterval(function () {
          if (studentNumber < 50) {
            randomCount = 5
          } else if (studentNumber >= 50) {
            randomCount = 10
          }
          pages.setData({
            random: random,
            student_number: studentNumber,
            randomCount: randomCount
          })
          // }, 50)
          var data = {
            'student_number': studentNumber,
            'id': id
          };
          randomStudent(data).then(res => {
            console.log(res);
            //记载学生人数请求成
            if (res.data.code == 1) {
              pages.setData({
                about: true
              })
            } else if (res.data.code == -1) {
              alert('后台服务器崩了?')
            }
          })
        },
      })
    }
  },
  pass: function (e) {
    console.log(e);
    var student_id = this.data.random;
    var student_type = e.currentTarget.dataset.studenttype;
    var student_number1 = this.data.student_number;
    var randomCount = this.data.randomCount - 1;
    var about = true;
    if (randomCount == 0) {
      about = false
    }
    var id = this.data.id;
    var pages = this;
    var data = {
      'student_id': student_id,
      'id': id,
      'student_type': student_type,
    };
    randomPassStudent(data).then(res => {
      console.log(res);
      //请求成功
      if (res.data.code == 1) {
        showToast1(res.data.msg, 'success');
      } else if (res.data.code == -1) {
        showToast1(res.data.msg, 'none');
      }
      var random = Math.ceil(Math.random() * student_number1);//随机数
      pages.setData({
        random: random,
        randomCount: randomCount,
        about: about,
      })
    });
  },
  location: function () {
    //老师点名
    if (types == 1) {

    } else if (types == 0) {
      //学生签到
      let url = '/pages/rollcall/rollcall';
      navigateTo(url);
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})