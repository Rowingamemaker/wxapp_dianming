
Page({

  /**
   * 页面的初始数据
   */
  data: {
    text1: '',
    text2: '',
    text3: '',
    text4: '',
    text5: '',
    text6: '',
    text7: '',
    text8: '',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // topText = ["1", "2", "3", "4", "5", "6", "7", "8"];

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var pages = this;
    var topText = [];
    var rangArr = [
      {
        endText: '1',
        texts: topText,
        beginTime: 500,
        spacetime: 10,
        stime: 500
      }
    ];
    var studentNumber = 54;
    var randomLength = 10;//随机点名的学生数
    for (var i = 0; i < randomLength; i++) {
      var random = Math.ceil(Math.random() * studentNumber);//随机数
      // topText[i] = random;
      var random1 = Math.ceil(Math.random() * studentNumber);//随机数
      var beginTime = beginTime + 500;
      var data = {
        endText: random1,
        texts: random,
        beginTime: 500,
        spacetime: 10,
        stime: 500
      };
      rangArr.push(data);
      // rangArr[i].endText = random1;
      // rangArr[i].texts = random;
      // rangArr[i].beginTime += 500;
      // rangArr[i].stime = 500;
      // rangArr[i].spacetime = 10;

    }
    console.log(rangArr);
    randDomText(pages, rangArr);
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
// 文字闪烁动画
function randDomText(pages, rangArr) {//endText最终显示文字，texts闪烁文字，time延迟时间,spacetime闪烁频率,stime闪烁周期
  var topText = topText;
  var allSpaceTime = 50;//线程执行间隔时间
  var animateinterval = '';
  var rangArr = rangArr;
  var that = pages;
  for (var i = 0; i < rangArr.length; i++) {
    var rang = rangArr[i];
    rang['runTime'] = 0;   //累计运行时间
    rang['isRun'] = false; //是否已经开始在执行了
    rang['isStop'] = false;//是否已经执行完毕了
  };

  animateinterval = setInterval(function () {
    var stop = true;
    var showData = {};
    for (var i = 0; i < rangArr.length; i++) {
      var rangXX = rangArr[i];
      if (!rangXX['isStop']) {
        stop = false; //只要有一个没执行完就 就继续执行 
        rangXX['runTime'] = rangXX['runTime'] + allSpaceTime; //累计执行时间开始叠加 
        var changeWord = false; //是否修改词
        if (!rangXX['isRun']) { //如果还没开始跑，判断下时间是否已经到开始跑的时间
          if (rangXX['runTime'] >= rangXX['beginTime']) {//
            rangXX['isRun'] = true;//到开始跑时间了
          } else {
            continue;
          }
        } else if (rangXX['runTime'] >= (rangXX['stime'] + rangXX['beginTime'])) {   //如果当前队列的已经执行完毕，则显示最后一次的数据         
          rangXX['isStop'] = true;
          if (rangXX['lastWord'] != rangXX['endText']) {
            rangXX['lastWord'] = rangXX['endText'];
            showData['text' + (i + 1)] = rangXX['endText'];//显示最后的词
          }
          continue;
        }
        var index = Math.floor((rangXX['runTime'] - rangXX['beginTime']) / rangXX['spacetime']) % rangXX['texts'].length;
        var showWord = rangXX['texts'][index];
        if (rangXX['lastWord'] != showWord) {
          rangXX['lastWord'] = showWord;
          showData['text' + (i + 1)] = showWord;
        }

      } else {
        continue;
      }
    }

    if (JSON.stringify(showData) != "{}") {
      that.setData(showData);
    }
    if (stop) {
      clearInterval(animateinterval);
    }
  }, allSpaceTime);
}