import { $wuxPrompt } from '../../components/wux';
import { getRooms, getStudents, getRoomType, signIn, getStudentAddress, qrcodeSignIn, getRoomTotalNumber } from '../../api.js';
var bmap = require('../../utils/bmap-wx.min.js');
import { showToast1 } from '../../utils/common.js';

const sliderWidth = 96;
Page({
  data: {
    tabs: ['旷课', '迟到', '正常'],
    activeIndex: '0',
    sliderOffset: 0,
    sliderLeft: 0,
    students: [],//学生数组
    name: 'Rowin',
    studentType: [],
    signInType: 0,//0:二维码 1:地址位置 2:蓝牙 3:随机
    markers: '',
    latitude: '',
    longitude: '',
    room_id: '',//该房间的id号
    address: '',
  },
  onLoad: function (options) {
    var pages = this;
    var room_id = options.room_id;
    getRoomTotalNumber({ 'room_id': room_id }).then(res => {
      if (res.data.code == 1) {
        wx.setNavigationBarTitle({
          title: '总学生数:' + res.data.data.total_number
        })
      } else {
        wx.setNavigationBarTitle({
          title: '教室:' + options.room_id
        })
      }
    })
    var tabs = ['旷课', '迟到', '正常'];
    getRoomType({ 'id': room_id }).then(res => {
      if (res.data.code == 1) {
        console.log(res);
        pages.setData({
          signInType: res.data.data.sign_in_type,
          room_id: room_id
        })
      }
    });
    getStudentAddress().then(res => {
      if (res.data.code == 1) {
        pages.setData({
          address: res.data.data
        })
      }
    })
    thisGetStudents(pages, room_id, tabs);
    $wuxPrompt.init('msg1', {
      title: '空空如也',
      text: '暂时没有相关数据',
    }).show()

    $wuxPrompt.init('msg2', {
      icon: '../../assets/images/iconfont-order.png',
      title: '您还没有相关的订单',
      text: '可以去看看有哪些想买',
      buttons: [
        {
          text: '随便逛逛'
        }
      ],
      buttonClicked(index, item) {
        console.log(index, item)
      },
    }).show()

    $wuxPrompt.init('msg3', {
      icon: '../../assets/images/iconfont-empty.png',
      title: '暂无待评价订单',
    }).show()

    this.getSystemInfo()
  },
  getSystemInfo() {
    const that = this
    wx.getSystemInfo({
      success(res) {
        that.setData({
          sliderLeft: (res.windowWidth / that.data.tabs.length - sliderWidth) / 2,
        })
      }
    })
  },
  tabClick(e) {
    this.setData({
      sliderOffset: e.currentTarget.offsetLeft,
      activeIndex: e.currentTarget.id,
    })
  },
  //学生身份   地址位置签到
  signIn: function () {
    var pages = this;
    var tabs = ['旷课', '迟到', '正常'];
    signIn({ 'room_id': pages.data.room_id }).then(res => {
      console.log(res);
      pages.setData({
        address: res.data.data.address
      })
      if (res.data.code == 1) {
        thisGetStudents(pages, pages.data.room_id, tabs)
        showToast1(res.data.msg, 'successs');
      } else if (res.data.code == -1) {
        showToast1(res.data.msg, 'none');
      }
    });
    //获取位置
    // wx.getLocation({
    //   altitude: true,
    //   success: function (res) {
    //     console.log(res);
    //     wx.request({
    //       url: 'http://api.map.baidu.com/geocoder/v2/?ak=kwb5tspgdNBF5GRQ6UyR17zFqFrdLXRc&location=' + res.latitude + ',' + res.longitude + '&output=json&coordtype=wgs84ll',
    //       header: {
    //         'Content-Type': 'application/json'
    //       },
    //       method: 'GET',
    //       dataType: 'json',
    //       success: function (res) {
    //         console.log(res);
    //         var formatted_address = res.data.result.formatted_address;
    //         var sematic_description = res.data.result.sematic_description;
    //         console.log(formatted_address)
    //         wx.request({
    //           url: api.default.signInAdd,
    //           data: {
    //             'sematic_description': sematic_description,
    //             'formatted_address': formatted_address
    //           },
    //           header: {
    //             'Content-Type': 'application/json'
    //           },
    //           method: 'GET',
    //           success: function (res) {
    //               //添加成功
    //               if(res.data.code==1){
    //                 wx.showToast({
    //                   icon: 'success',
    //                   title: '签到成功',
    //                   mask: true
    //                 });
    //               }else if(res.data.code==-1){
    //                 wx.showToast({
    //                   icon: 'fail',
    //                   title: '签到失败',
    //                   mask: true
    //                 });
    //               }
    //           },
    //         })
    //       },
    //       fail: function (res) { },
    //       complete: function (res) { },
    //     })
    // },
    // fail: function (res) { },
    // complete: function (res) { },
    // })
  },
  //学生 扫码签到
  scanCode: function () {
    var pages = this;
    var tabs = ['旷课', '迟到', '正常'];
    wx.scanCode({
      onlyFromCamera: true,
      scanType: ['qrCode'],
      success: function (res) {
        console.log(res);
        if (res.path != '') {
          var path = res.path;
          var id = path.slice(24);
          console.log(id);
          qrcodeSignIn({ 'id': id }).then(res => {
            console.log(res)
            if (res.data.code == 1) {
              thisGetStudents(pages, pages.data.room_id, tabs)
              showToast1(res.data.msg, 'successs');
            } else {
              showToast1(res.data.msg, 'none');
            }
          })
        }
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
function thisGetStudents(pages, room_id, tabs) {
  var studentType = [];
  getStudents({ 'id': room_id }).then(res => {
    console.log(res);
    var data = res.data.data;
    if (res.data.code == 1) {
      pages.setData({
        students: data
      })
      var truancy = 0;
      var late = 0;
      var normal = 0;
      // 1:迟到 2:旷课  3:正常 
      console.log(data)
      for (var i in data) {
        if (data[i].studentSignInType == 2) {
          truancy++;
        } else if (data[i].studentSignInType == 3) {
          normal++
        } else if (data[i].studentSignInType == 1) {
          late++
        }
      }
      studentType = [truancy, late, normal]
      for (var i = 0; i < 3; i++) {
        tabs[i] += '(' + studentType[i] + ')';
      }
      pages.setData({
        studentType: studentType,
        tabs: tabs
      })
    }
  });
}