var app = getApp();
import { wxGet, wxPost, wxUploadFile } from '../../utils/wxRequest.js';
import { wxLogin } from '../../api.js';
import { showLoading, showToast1, redirectTo, switchTab } from '../../utils/common.js';
Page({
  data: {
    userType: ['学生', '老师'],
    index: 0,
    invalid: true,
    code: ''
  },
  bindPickerChange: function (e) {
    this.setData({
      index: e.detail.value
    })
  },
  bindIdInput: function (e) {
    this.setData({
      userId: e.detail.value
    })
  },
  bindNameInput: function (e) {
    this.setData({
      userName: e.detail.value
    })
    if (this.data.userName != '' && this.data.userId !== '') {
      this.setData({
        invalid: false
      })
    }
  },
  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数
    let pages = this;
    wx.login({
      success: function (res) {
        var code = res.code;
        pages.setData({
          code: code
        })
      },
    })
  },
  onReady: function () {
    // 页面渲染完成
  },
  onShow: function () {
    // 页面显示
    var pages = this;
    showLoading().then(res => {
      pages.isLogin();
    });
    this.isLogin();
  },
  //判断是否登录
  isLogin: function () {
    var token = wx.getStorageSync('token');
    console.log('下面这个token')
    console.log(token)
    if (token != '') {
      wx.switchTab({
        url: '/pages/index/index',
        complete: function (res) {
          wx.hideLoading();
        },
      })
    } else {
      wx.hideLoading();
    }
  },
  onHide: function () {
    // 页面隐藏
  },
  onUnload: function () {
    // 页面关闭

  },
  wxLogin: function (e) {
    // wx.openSetting({
    //   success: function(res) {   
    //     console.log(res)     
    //   },
      //   fail: function(res) {},
      //   complete: function(res) {},
      // }) 
    console.log(e);
    var data={};

    let pages = this;
    let userId = pages.data.userId;
    let userName = pages.data.userName;
    let code = pages.data.code;
    let type = pages.data.index;//0是学生,1是老师
    if (e.detail.errMsg == "getUserInfo:ok") {
      data = {
        'userId': userId,
        'userName': userName,
        'code': code,
        'type': type,
        'avatarUrl': e.detail.userInfo.avatarUrl,
        'nickName': e.detail.userInfo.nickName,
      };
    } else {
      data = {
        'userId': userId,
        'userName': userName,
        'code': code,
        'type': type,
      }
    }
    if (userId == '' || userId == undefined) {
      showToast1('请输入学号', 'none')
    } else if (userName == '' || userName == undefined) {
      showToast1('请输入姓名', 'none')
    } else {
        let res = wxLogin(data).then(res => {
          console.log(res);
          var code = res.data.code;
          //成功
          if (code == 1) {
            wx.setStorageSync('token', res.data.data.open_id);
            wx.setStorageSync('type', res.data.data.type);
            showToast1('注册成功', 'success');
            switchTab('../index/index')
          } else {
            showToast1('注册失败', 'none')  
          }
        });
      // console.log(res);
    }
  },
  // getUserInfo:function(e){
  //   console.log(e); 
  // }
})