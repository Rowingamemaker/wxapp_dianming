// var _api_root = 'https://flingspace.cn/bishe/public/admin/api/';
var _api_root = 'http://www.bobobishe.com/admin/api/';
import { wxGet, wxPost, uploadFile } from '/utils/wxRequest.js';
import { getLocation, chooseLocation } from '/utils/common.js';
var api = {
  //微信登陆
  wxLogin: function (data) {
    let url = _api_root + 'wxLogin';
    return wxPost(url, data);
    // console.log(res)
  },
  //点击签到
  signIn: function (data) {
    let url = _api_root + 'signIn';
    return getLocation().then(res => {
      return wxPost(url, { 'latitude': res.latitude, 'longitude': res.longitude, 'room_id': data.room_id })
    })
  },
  //创建教室
  createRoom: function (data) {
    let url = _api_root + 'createRoom';
    return wxPost(url, data);
  },
  //搜索教室
  searchRoom: function (data) {
    let url = _api_root + 'searchRoom';
    return wxPost(url, data);
  },
  //删除教室
  delRoom: function (data) {
    let url = _api_root + 'delRoom';
    return wxPost(url, data);
  },
  //修改教室名字
  updateRoomName: function (data) {
    let url = _api_root + 'updateRoomName';
    return wxPost(url, data);
  },
  //获取教师的所有教室
  getRooms(data) {
    let url = _api_root + 'getRooms';
    return wxGet(url);
  },
  //获取教室里所有学生的信息 是否签到 学号 名字  头像
  getStudents(data) {
    let url = _api_root + 'getStudents';
    return wxPost(url, data);
  },
  // 签到方式  生成教室的二维码 供学生签到使用
  getQrcode(data) {
    let url = _api_root + 'getQrcode';
    return wxPost(url, data);
  },
  //选择签到方式
  selectSignInType(data) {
    let url = _api_root + 'selectSignInType';
    return wxPost(url, data);
  },
  // 签到方式  位置点名
  roomAddress(data) {
    let url = _api_root + 'roomAddress';
    return wxPost(url, data);
  },
  //签到方式 随机点名
  randomStudent(data) {
    let url = _api_root + 'randomStudent';
    return wxPost(url, data);
  },
  //随机签到 pass
  randomPassStudent(data) {
    let url = _api_root + 'randomPassStudent';
    return wxPost(url, data);
  },
  //获取教室的签到类型
  getRoomType(data) {
    let url = _api_root + 'getRoomType';
    return wxPost(url, data);
  },
  //地理签到中 获取学生的address
  getStudentAddress() {
    let url = _api_root + 'getStudentAddress';
    return wxGet(url);
  },
  //通过room_id查找教室总人数
  getRoomTotalNumber(data){
    let url = _api_root + 'getRoomTotalNumber';
    return wxPost(url, data);
  },
  qrcodeSignIn(data) {
    let url = _api_root + 'qrcodeSignIn';
    return wxPost(url, data);
  }
};
module.exports = api;