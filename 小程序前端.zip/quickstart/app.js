//app.js
import { redirectTo, showLoading } from '/utils/common.js';

App({
  onLaunch: function (e) {
    //在二维码签到模式中  设置只能通过扫码才能进入签到
    console.log(e);
    //如果二维码中带参数并且是通过扫码进入签到
    console.log(typeof (e.query.id));
    if ((typeof (e.query.id) != 'undefined') && e.scene == '1011') {
      wx.redirectTo({
        url: 'pages/warn/warn',
      })
    }
    // var app = this;
    // showLoading().then(res => {
    //   app.isLogin();
    // });
  },
  getUserInfo: function (cb) {
    var that = this;
    if (this.globalData.userInfo) {
      typeof cb == "function" && cb(this.globalData.userInfo)
    } else {
      //调用登录接口  
      wx.login({
        success: function () {
          wx.getUserInfo({
            success: function (res) {
              that.globalData.userInfo = res.userInfo;
              typeof cb == "function" && cb(that.globalData.userInfo)
            }
          })
        }
      });
    }
  },
  // //判断是否登录
  // isLogin: function () {
  //   var token = wx.getStorageSync('token');
  //   console.log('下面这个token')
  //   console.log(token)
  //   if (token != '') {
  //     wx.switchTab({
  //       url: '/pages/index/index',
  //       complete: function (res) {
  //         wx.hideLoading();
  //       },
  //     })
  //   }else{
  //     wx.redirectTo({
  //       url: '/pages/login/login',
  //       complete: function (res) {
  //         wx.hideLoading();
  //       },
  //     })
  //   }
  // },
  globalData: {
    userInfo: null
  }
})