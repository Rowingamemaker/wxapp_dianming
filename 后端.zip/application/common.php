<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 应用公共文件
//密码加密
function md112($password)
{
    $salt = 'xixi';//加盐
    return md5($password) . $salt;
}

//get方法
function curl_get($url, &$httpCode = 0)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    //不做证书验证.部署在linux环境下请改为true
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    $file_contents = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $file_contents;
}

//post方法
function curl_post($url, $data)
{
    $ch = curl_init();
    $timeout = 30;
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    @curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

    $result = curl_exec($ch);
    curl_close($ch);
    $out = json_decode($result);
    return $out;
}

//https的post方法
function post_https_array($url, $post_data)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    // curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);   //没有这个会自动输出，不用print_r();也会在后面多个1
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
    $output = curl_exec($ch);

    curl_close($ch);
    $out = json_decode($output);

    return $out;
}


//获取openid
function get_openid($code)
{
    $appid = 'wxf5679c79901cbc57';
    $appsecret = '2972ed0d99151922253b983bfd4ab81c';
    $code = $code;
    $url = "https://api.weixin.qq.com/sns/jscode2session?appid=$appid&secret=$appsecret&js_code=$code&grant_type=authorization_code";
    $res = curl_get($url);
    $result = json_decode($res, true);
    if (isset($result['openid'])) {
        return $result['openid'];
    }
    return false;
}

//获取access_token
function getAccessToken()
{
    $appid = config('wx.app_id');
    $appsecret = config('wx.app_secret');
    $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$appid&secret=$appsecret";
    $res = curl_get($url);
    $result = json_decode($res, true);

    if (isset($result['access_token'])) {
        return $result['access_token'];
    }
    return false;
}

//{"path":"pages/index/index","width":430,"auto_color":false,"line_color":{"r":"0","g":"0","b":"0"}}
//获取小程序码    接口B
function getWxQrcode()
{

}


//2 通过经纬度获取地址百度地图 $local = 维度,经度  (22.543099,114.057868)
function getGaoDeAddress($local = '')
{
    $key = config('map.GaoDeKey');
    //    $url = "http://restapi.amap.com/v3/geocode/regeo?output=json&location=$local&key=$key";
    $url = "http://api.map.baidu.com/geocoder/v2/?ak=$key&location=$local&output=json&coordtype=wgs84ll";
    $res = curl_get($url);
    $result = json_decode($res, true);
    //$this->ajaxReturn($result);
    return $result;
}

//2 通过经纬度获取地址 腾讯地图 $local = 维度,经度  (22.543099,114.057868)
function getTenXunAddress($local = '')
{
    $key = config('map.TentXunKey');
    $url = "http://apis.map.qq.com/ws/geocoder/v1/?location=$local&key=$key&get_poi=0";
    $res = curl_get($url);
    $result = json_decode($res, true);
    //$this->ajaxReturn($result);
    return $result;
}

//返回数组定义
function returnData($code = 1, $msg = '', $data = [])
{
    return json(array(
        'code' => $code,
        'msg' => $msg,
        'data' => $data
    ));
}

//总的学生人数
function totalNumber($room_id)
{
    //?    $schoolRoom = new SchoolRoom();
    $schoolRoom = new \app\admin\model\SchoolRoom();
    $students = $schoolRoom->getOkStudents(array('id' => $room_id));
    $count = count($students);
    if ($count==1){
        return 0;
    }
    return $count;
}
function getTeacher($id){
    $schoolTeacher=new \app\admin\model\SchoolTeacher();
    $res=$schoolTeacher->where('id',$id)->value('teacher_name');
    if (isset($res))
        return $res;
    return '0.0';
}