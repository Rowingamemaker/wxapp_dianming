<?php
/**
 * Created by PhpStorm.
 * Students: Rowin
 * Date: 2018/5/16
 * Time: 10:30
 */

namespace app\admin\controller;


use app\admin\model\SchoolStudent;
use think\facade\Request;

class Students extends Base
{
    public function index(){
        $schoolStudent=new SchoolStudent();
        $list=$schoolStudent->getAllStudents();
        $this->assign('list',$list);
        $page = $list->render();
        $this->assign('page', $page);
        return $this->fetch();
    }
    //删除学生信息
    public function delStudent(){
        $params=Request::param();
        if (isset($params['id'])){
            $schoolStudent=new SchoolStudent();
            $res=$schoolStudent->delStudents($params['id']);
            if ($res){
                return returnData('1','删除成功');
            }else{
                return returnData('-1','删除失败');

            }
        }
    }
}