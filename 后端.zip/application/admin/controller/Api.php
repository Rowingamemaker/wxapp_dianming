<?php
/**
 * Created by PhpStorm.
 * Students: Rowin
 * Date: 2018/5/4
 * Time: 5:56
 */

namespace app\admin\controller;

use app\admin\model\SchoolRoom;
use app\admin\model\SchoolSignin;
use app\admin\model\SchoolStudent;
use app\admin\model\SchoolTeacher;
use think\Db;
use think\facade\Request;
use think\Controller;

//Api接口
class Api extends Controller
{
    public function index()
    {
        echo 'Api接口~~~~';
    }
    //检查是否登录
    public function check()
    {
        $token = Request::header('token');
        if (!(isset($token) && $token != '')) {
            return returnData('-1', '没有token');
        }
        $type = Request::header('type');
        //学生登录请求'
        $userId = '';
        if ($type == 0) {
            $schoolStudent = new SchoolStudent();
            $userId = $schoolStudent->userId($token);
        } else if ($type == 1) {
            $schoolTeacher = new SchoolTeacher();
            $userId = $schoolTeacher->userId($token);
        }
        if ($userId != '') {
            return $userId;
        }
        //        if ($studentId == $teacherId) {
        //            return returnData('-1', '请勿同时注册学号和老师');
        //        }
        //        if ($studentId != '' || $teacherId != '') {
        //            $userId = $studentId == '' ? $schoolTeacher : $studentId;
        //            return $userId;
        //        }

    }
    //签到记录添加
    public function signInAdd()
    {
        $userId = $this->check();
        $params = Request::param();
        if (!isset($params)) {
            return returnData('-1', '添加失败');
        } elseif (!isset($params['sematic_description'])) {
            return returnData('-1', '添加失败');
        } elseif (!isset($params['formatted_address'])) {
            return returnData('-1', '添加失败');
        } else {
            $schoolSignin = new SchoolSignin();
            $res = $schoolSignin->signInAdd($params);
            if ($res) {
                return returnData('1', '添加成功');
            }
            return returnData('-1', '添加失败');
        }
    }
    //地理位置签到
    public function signIn()
    {
        $params = Request::param();

        $userId = $this->check();//学生id
        if (!isset($params)) {
            return returnData('-1', '位置发送失败');
        } elseif (!isset($params['latitude'])) {
            return returnData('-1', '经度发送失败');
        } elseif (!isset($params['longitude'])) {
            return returnData('-1', '纬度发送失败');
        } else {
            $schoolSignin = new SchoolSignin();
            $local = $params['latitude'] . ',' . $params['longitude'];
            $tentXun = getTenXunAddress($local);
            $data = array(
                'student_id' => $userId,
                'latitude' => $params['latitude'],
                'longitude' => $params['longitude'],
                'room_id' => $params['room_id'],
                'address' => $tentXun['result']['address'], ///福建省厦门市思明区民族路33号
                'nation' => $tentXun['result']['address_component']['nation'],
                'province' => $tentXun['result']['address_component']['province'],
                'city' => $tentXun['result']['address_component']['city'],
                'district' => $tentXun['result']['address_component']['district'],
                'street' => $tentXun['result']['address_component']['street'],
                'street_number' => $tentXun['result']['address_component']['street_number'],
            );
            $data1 = array(
                'student_id' => $userId,
                'id' => $params['room_id'],
            );
            $res = $schoolSignin->signIn($data);
            $res1 = $this->insertSchoolRoom($data1);
            if ($res && $res1) {
                return returnData('1', '签到成功', $data);
            }
            return returnData('-1', '已签到');
        }
        return returnData('-1', '签到失败');
    }
    //地址位置签到时  向schoolroom表加入学生  1:迟到 2:旷课  3:正常
    public function insertSchoolRoom($data)
    {
        $studentSignInType = 3;
        $data = array(
            'student_id' => $data['student_id'],
            'id' => $data['id'],
        );
        $schoolRoom = new SchoolRoom();
        $res = $schoolRoom->students($data, $studentSignInType);
        if ($res) {
            return true;
        }
        return false;
    }
    //微信登陆
    public function wxLogin()
    {

        //        echo config('wx.app_id');
        $params = Request::param();
        //        var_dump($params);
        if (!isset($params['code']) || !isset($params['userId']) || !isset($params['userName']) || !isset($params['type'])) {
            return returnData('-1', '参数错误,登录失败');
        }
        $openId = get_openid($params['code']);
        if (!$openId) {
            return returnData('-1', 'openid的问题呀~~~登录失败');
        }
        $data = [];
        $res = '';
        $avatarUrl = '';
        $nickName = '';
        if (isset($params['avatarUrl'])) {
            $avatarUrl = $params['avatarUrl'];
            $nickName = $params['nickName'];
        }
        //判断是学生登录还是老师登录
        if ($params['type'] == 0) {
            //学生登录
            $data = array(
                'student_id' => $params['userId'],
                'student_name' => $params['userName'],
                'open_id' => $openId,
                'type' => 0,
                'avatarUrl' => $avatarUrl,
                'nickName' => $nickName
            );
            $login = new SchoolStudent();
            $res = $login->wxLogin($data);

        } else {
            //老师登录
            $data = array(
                'teacher_id' => $params['userId'],
                'teacher_name' => $params['userName'],
                'open_id' => $openId,
                'type' => 1,
                'avatarUrl' => $avatarUrl,
                'nickName' => $nickName
            );
            $login = new SchoolTeacher();
            $res = $login->wxLogin($data);

        }
        if ($res) {
            return returnData('1', '登录成功', $data);
        }
        return returnData('-1', '登录失败');
    }
    //创建教室
    //待修改
    public function createRoom()
    {
        //获取该老师的userId
        $userId = $this->check();
        $params = Request::param();
        //参数校验
        if (!isset($params['room_id']) || $params['room_id'] == '') {
            return returnData('-1', '缺少教室编号');
        }
        $type = Request::header('type');
        if ($type == 0) {
            return returnData('-1', '学生不能创建教室');
        } else if ($type == 1) {
            //            $schoolTeacher=new  SchoolTeacher();
            $data = array(
                'room_id' => $params['room_id'],//教室编号
                'total_number' => $params['total_number'],//教室编号
                'teacher_id' => $userId,
            );
            $schoolRoom = new SchoolRoom();
            $res = $schoolRoom->createRoom($data);
            if (is_numeric($res)) {
                //返回教室id
                return returnData('1', '教室创建成功', $res);
            } else if ($res === false) {
                return returnData('-1', '教室创建失败');
            } else {
                //返回教室名
                return returnData('0', '教室已存在', $res);

            }
        } else {
            return returnData('-1', '用户类型异常');
        }

    }
    //删除教室
    public function delRoom()
    {
        //获取该老师的userId
        $userId = $this->check();
        $params = Request::param();
        //要从room数据库删除的主键
        $id = $params['id'];
        $data = array(
            'id' => $id,
            'teacher_id' => $userId
        );
        $schoolRoom = new SchoolRoom();
        $res = $schoolRoom->delRoom($data);
        if (isset($res)) {
            return returnData('1', '删除教室成功', $res);
        }
        return returnData('-1', '删除教室失败');
    }
    //获取教室
    public function getRooms()
    {
        //获取登陆校验参数
        $token = Request::header('token');
        $type = Request::header('type');
        //type为1则是老师登陆
        if ($type == 1) {
            //获取该老师的userId
            $schoolTeacher = new SchoolTeacher();
            $userId = $schoolTeacher->userId($token);
            ///查找该老师的所有教室  分页返回
            $schoolRoom = new SchoolRoom();
            $res = $schoolRoom->getRooms($userId);
            if ($res !== false) {
                return returnData('1', '获取教室数据成功', $res);
            } else {
                return returnData('-1', '暂无教室');
            }
        }
        return returnData('-1', '老师才能获取教室信息');
    }
    //更改教室名字
    public function updateRoomName()
    {
        //        $userId = $this->check();
        $params = Request::param();
        $id = $params['id'];
        $roomId = $params['room_id'];
        $data = array(
            'room_id' => $roomId
        );
        $school = new SchoolRoom();
        $res = $school->updateRoomName($id, $data);
        if ($res) {
            return returnData('1', '修改教室名成功');
        }
        return returnData('-1', '修改教室名失败');
    }
    //获取教室里所有学生学号 学生ID 1:迟到 2:旷课  3:正常
    public function getStudents($id)
    {
        //        $userId = $this->check();
        $params = Request::param();
        $id = $params['id'];
        $data = array(
            'id' => $id
        );
        $schoolRoom = new SchoolRoom();
        $students = $schoolRoom->getStudents($data);
        if (isset($students)) {
            return returnData('1', 'success get Students Message~~~', $students);
        }
        return returnData('-1', 'you fail~~~');
    }
    // 0:二维码 1:地址位置 3:蓝牙 4:随机
    public function selectSignInType()
    {
        //        header('content-type:image/jpg');
        $params = Request::param();
        $id = $params['id'];
        $sign_in_type = $params['sign_in_type'];
        if (!isset($id) || !isset($sign_in_type) || $id == '' || $sign_in_type == '') {
            returnData('-1', '选择签到方式错误,缺少id或签到类型');
        }
        $schoolRoom = new SchoolRoom();
        $data = array(
            'id' => $id,
            'sign_in_type' => $sign_in_type
        );
        $res = $schoolRoom->selectSignInType($data);
        if ($res) {
            if ($sign_in_type == 0) {
                $url = "http://www.bobobishe.com/admin/api/getQrcode/scene/$id";
                return returnData('1', '选择了二维码签到方式', $url);
                //                $this->getQrcode($id);
            }
        } else {
            return returnData('-1', '不存在该教室id,请联系Rowin管理员');
        }
        return returnData('-1', '选择方式失败');
    }
    //生成对应教室的二维码  供学生签到使用
    public function getQrcode($scene, $page = 'pages/index/index')
    {
        header('content-type:image/jpg');
        $accessToken = getAccessToken();
        $url = "https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token=$accessToken";
        //post参数  以json形式
        $data = array(
            'scene' => $scene,
            'page' => $page
        );
        $data = json_encode($data);
        post_https_array($url, $data);
    }
    public function getQrcode2($scene, $page = 'pages/index/index')
    {

        header('content-type:text/html');
        $accessToken = getAccessToken();
        $url = "https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token=$accessToken";
        //post参数  以json形式
        $data = array(
            'scene' => 'id=26',
            'page' => $page
        );
        $data = json_encode($data);
        return post($url, $data);
    }
    //二维码签到
    public function qrcodeSignIn()
    {
        $userId = $this->check();
        $params = Request::param();
        $id = $params['id'];
        $student_type=3;//3正常
        if ( !isset($id)  ||$id == '') {
            return returnData('-1', 'id或者学号错误');
        }
        $data = array(
            'student_id' => $userId,
            'id' => $id,
        );
        $schoolRoom = new SchoolRoom();
        $res = $schoolRoom->students($data, $student_type);
        if ($res) {
            return returnData('1', '点名成功', $res);
        }
        return returnData('-1', '已点完或出bug了,请联系管理员');

    }
    //教室点名的地址记录
    //教室为中心的地理位置
    public function roomAddress()
    {

        $params = Request::param();
        $latitude = $params['latitude'];
        $id = $params['id'];

        $longitude = $params['longitude'];
        if (!isset($longitude) || !isset($latitude) || $longitude == '' || $latitude == '') {
            return returnData('-1', '无经纬度~~~~~~~~0.0');
        }
        $local = $latitude . ',' . $longitude;
        $tentXun = getTenXunAddress($local);
        $data = array(
            'id' => $id,
            'sign_in_type' => 1,
            'latitude' => $latitude,
            'longitude' => $longitude,
            'room_address' => $tentXun['result']['address'] ///福建省厦门市思明区民族路33号
        );
        if (!isset($tentXun) || $tentXun == '') {
            return returnData('-1', '腾讯地图坏了,请找工程师');
        } else {
            $schoolRoom = new SchoolRoom();
            $res = $schoolRoom->roomAddress($data);
            return returnData('1', '腾讯地图请求成功', $res);
        }
    }
    //生成随机签到的学生
    public function randomStudent()
    {
        $params = Request::param();
        $student_number = $params['student_number'];
        $id = $params['id'];
        if (!isset($student_number) || !isset($id) || $student_number == '' || $id == '') {
            return returnData('-1', 'id或者学号人数错误');
        }
        $data = array(
            'id' => $id,
            'student_number' => $student_number
        );
        $schoolRoom = new SchoolRoom();
        $res = $schoolRoom->randomStudent($data);
        if ($res) {
            return returnData('1', '人数记载成功', $res);
        }
        return returnData('-1', '随机方法错误');
    }
    //学生ID 1:迟到 2:旷课  3:正常
    public function randomPassStudent()
    {
        $params = Request::param();
        $student_id = $params['student_id'];
        $student_type = $params['student_type'];
        $id = $params['id'];
        if (!isset($student_id) || !isset($id) || $student_id == '' || $id == '') {
            return returnData('-1', 'id或者学号错误');
        }
        $data = array(
            'student_id' => $student_id,
            'id' => $id,
        );
        $schoolRoom = new SchoolRoom();
        $res = $schoolRoom->students($data, $student_type);
        if ($res) {
            return returnData('1', '点名成功', $res);
        }
        return returnData('-1', '已点完或出bug了,请联系管理员');

    }
    //学生搜索教室
    public function searchRoom()
    {
        $params = Request::param();
        $room_id = $params['room_id'];
        if (!isset($room_id) || $room_id == '') {
            # code...
            return false;
        }
        $schoolRoom = new SchoolRoom();
        $data = array(
            'room_id' => $room_id
        );
        $res = $schoolRoom->searchRoom($data);
        if ($res) {
            # code...
            return returnData('1', '教室搜索成功', $res);
        }
        return returnData('-1', '未搜索到该教室~~~~');
    }
    //获取该教室的签到类型
    public function getRoomType()
    {
        $params = Request::param();
        $id = $params['id'];
        if (!isset($id) || $id == '') {
            # code...
            return false;
        }
        $schoolRoom = new SchoolRoom();
        $data = array(
            'id' => $id
        );
        $res = $schoolRoom->getRoomType($data);
        if (isset($res)) {
            return returnData('1', '获取教室签到类型成功', $res);
        }
        return returnData('-1', '获取教室签到类型失败');
    }
    //地理签到中 获取学生的address
    public function getStudentAddress()
    {
        $userId = $this->check();
        $address = Db::name('school_signin')->where('student_id', $userId)->value('address');
        if (isset($address) && ($address != '')) {
            return returnData('1', '获取单个学生的address成功', $address);
        }
        return returnData('-1', '获取单个学生的address失败');
    }
    //通过room_id查找教室总人数
    public function getRoomTotalNumber(){
        $params = Request::param();
        $room_id = $params['room_id'];
        if (!isset($room_id) || $room_id == '') {
            # code...
            return returnData('-1', 'you fail');
        }
        $schoolRoom=new SchoolRoom();
        $totalNumber=$schoolRoom->getRoomTotalNumber($room_id);
        if ($totalNumber){
                return returnData(1,'查找成功',$totalNumber);
        }
        return returnData(-1,'you failllllllL~~~~~~~~~~~~~~~~~');
    }
}