<?php
/**
 * Created by PhpStorm.
 * Students: Rowin
 * Date: 2018/5/3
 * Time: 19:33
 */

namespace app\admin\controller;

use app\admin\model\SchoolAdmin;
use app\admin\model\SchoolSignin;
use think\Controller;
use think\facade\Request;

//后台登陆
class Admin extends Base
{
    protected $beforeActionList = [
        'login' => ['index']
    ];

    //后台首页
    public function index()
    {
        return $this->fetch();
    }

    //登陆
    public function login()
    {
        if (empty(session('admin'))) {
            return $this->redirect('Login/index');
        }
    }

    //签到管理
    public function signIn()
    {
        //        $schoolSignin=new SchoolSignin();
        $schoolSignin = new SchoolSignin();
        $list = $schoolSignin->signInSelect();
        $this->assign('list', $list);
        //        return json($list);
        return $this->fetch();
    }

}