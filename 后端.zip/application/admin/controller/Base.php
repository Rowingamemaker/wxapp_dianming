<?php
/**
 * Created by PhpStorm.
 * Students: Rowin
 * Date: 2018/5/3
 * Time: 19:36
 */

namespace app\admin\controller;
use think\Controller;
//后台登陆检验模块
class Base extends Controller
{
//    protected $beforeActionList = [
//        'Login',
//    ];
//    //登陆校验
//    public  function Login(){
////        echo 'Login';
//
//    }
    public function index(){
        return 'index';
    }

}