<?php
/**
 * Created by PhpStorm.
 * Students: Rowin
 * Date: 2018/5/16
 * Time: 10:01
 */

namespace app\admin\controller;


class Practice extends Base
{
    public function index()
    {
        return $this->fetch();
    }
}