<?php
/**
 * Created by PhpStorm.
 * Students: Rowin
 * Date: 2018/5/16
 * Time: 10:30
 */

namespace app\admin\controller;


use app\admin\model\SchoolTeacher;

class Teachers extends Base
{
    public function index()
    {
        $schoolTeacher = new SchoolTeacher();
        $list = $schoolTeacher->getAllTeachers();
        $this->assign('list', $list);
        return $this->fetch();
    }


    //删除学生信息
    public function delTeacher()
    {
        $params = Request::param();
        if (isset($params['id'])) {
            $schoolTeacher = new SchoolTeacher();
            $res = $schoolTeacher->delTeacher($params['id']);
            if ($res) {
                return returnData('1', '删除成功');
            } else {
                return returnData('-1', '删除失败');

            }
        }
    }
}