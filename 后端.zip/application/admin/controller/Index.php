<?php
/**
 * Created by PhpStorm.
 * Students: Rowin
 * Date: 2018/5/3
 * Time: 19:38
 */

namespace app\admin\controller;
use think\Controller;
//后台登陆
class Index  extends Base
{
    public  function index(){
//        echo 'Admin';
        return $this->fetch();
    }
    public function login(){
        return $this->fetch();
    }
}