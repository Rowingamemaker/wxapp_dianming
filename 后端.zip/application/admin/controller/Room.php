<?php
/**
 * Created by PhpStorm.
 * Students: Rowin
 * Date: 2018/5/16
 * Time: 9:59
 */

namespace app\admin\controller;


use app\admin\model\SchoolRoom;

class Room extends Base
{
    public function index()
    {
        $schoolRoom = new SchoolRoom();
        $list = $schoolRoom->getAllRooms();
//        $students=$schoolRoom->getOkStudents(array('id'=>38));
//        return ($students);
//        $count=count($students);
//        var_dump($count);
//        die();
//        $order_students=count($students);
//        $this->assign('count',$count);
//        $this->assign('students',$students);
//        $this->assign('students',$students);
//        return totalNumber(38);
        $this->assign('list', $list);
        return $this->fetch();
    }


    //删除学生信息
    public function delTeacher()
    {
        $params = Request::param();
        if (isset($params['id'])) {
            $schoolTeacher = new SchoolTeacher();
            $res = $schoolTeacher->delTeacher($params['id']);
            if ($res) {
                return returnData('1', '删除成功');
            } else {
                return returnData('-1', '删除失败');

            }
        }
    }
}