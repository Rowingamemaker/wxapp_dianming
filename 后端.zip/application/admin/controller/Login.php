<?php
/**
 * Created by PhpStorm.
 * Students: Rowin
 * Date: 2018/5/10
 * Time: 17:27
 */

namespace app\admin\controller;


use app\admin\model\SchoolAdmin;
use think\Controller;
use think\facade\Request;

class Login extends Controller
{
    public function index()
    {
        return $this->fetch();
    }
    //登陆验证
    public function ajaxLogin()
    {
        $data = array();
        $params = Request::param();
        //                var_dump($params);
        //        die();
        //判断是否为空
        if (!isset($params["username"]) && $params["username"] == '') {
            $this->error('请输入账号');
        } elseif (!isset($params['password']) && $params['password'] == '') {
            $this->error('请输入密码');
        } else {
            $data['admin_username'] = $params['username'];
            //参数加密校验
            $data['admin_password'] = md112($params['password']);
            $schoolAdmin = new SchoolAdmin();
            $res = $schoolAdmin->checkoutAdmin($data);
        }
        if ($res) {
            //            $this->success('登陆成功');
            session('admin', $data['admin_username']);
            return $this->success('登陆成功','Admin/index');
        } else {
            $this->error('密码错误或账号不存在');
        }
    }
    //注销
    public function delAdmin()
    {
        session('admin', null);
        $this->success('注销成功', 'Login/index');

    }
    //注册
    public function changeAdmin()
    {
        return $this->fetch();
    }
    public function ajaxChangeName(){
        $params = Request::param();
        //                var_dump($params);
        //        die();
        //判断是否为空
        if (!isset($params["username"]) && $params["username"] == '') {
            $this->error('请输入账号');
        } elseif (!isset($params['password']) && $params['password'] == '') {
            $this->error('请输入密码');
        }else{
            $schoolAdmin=new SchoolAdmin();
            $data=array(
                'admin_username'=>$params['username'],
                'admin_password'=>md112($params['password'])
            );
            $res=$schoolAdmin->changeAdmin($data);
            if ($res){
                $this->success('修改成功','Admin/index');
            }else{
                $this->error('修改失败');
            }
        }

    }
}