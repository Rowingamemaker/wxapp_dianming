<?php
/**
 * Created by PhpStorm.
 * Students: Rowin
 * Date: 2018/5/6
 * Time: 4:23
 */

namespace app\admin\model;


use think\Model;

class SchoolRoom extends Model
{
    //时间戳写入
    protected $autoWriteTimestamp = true;
    protected $json = ['students'];

    //创建教室
    public function createRoom($data)
    {

        $roomId = self::where('room_id', $data['room_id'])->find();
        if (isset($roomId)) {
            return $roomId['room_id'];
        }
        $res = self::allowField(true)->save($data);

        if ($res == 1) {
            $roomId = self::where('room_id', $data['room_id'])->find();
            //创建成功 返回房间id
            return $roomId['id'];
        }
        return false;
    }

    //删除教室
    public function delRoom($data)
    {
        //delete方法 成功则返回1  失败返回0
        $res = self::allowField(true)->where($data)->delete();
        $data = $this->getRooms($data['teacher_id']);
        if ($res == 1) {
            return $data;
        }
        return false;
    }

    //获取教室
    public function getRooms($userId)
    {
        $data = self::order(['id' => 'desc'])->where('teacher_id', $userId)->paginate(10);
        if (isset($data)) {
            return $data;
        } else {
            return false;
        }
    }
    public function getRoomTotalNumber($room_id){
        $res=self::where('room_id',$room_id)->value('total_number');
        if (isset($res))
            return $res;
        return false;
    }

    ///获取所有教室
    public function getAllRooms()
    {
        $data = self::order(['id' => 'desc'])->paginate(10);
        if (isset($data)) {
            return $data;
        } else {
            return false;
        }
    }

    //修改教室名字
    public function updateRoomName($userId, $data)
    {
        //修改成功返回1
        $res = self::allowField(true)->where('id', $userId)->update($data);
        if (isset($res) && $res == 1) {
            return true;
        }
        return false;
    }

    //获取该教室下的所有学生
    public function getStudents($data)
    {
        //单独返回students这个值
        $students = self::where('id', $data['id'])->value('students');

        $students = json_decode($students, true);

        //        foreach ($students as $key =>$value){
        //            array_keys
        //        }
        if (!empty($students))
            $studentsAllKey = array_keys($students);
        else
            return false;
        $student = new SchoolStudent();
        $lists = $student->allStudent($studentsAllKey);
        foreach ($lists as $key => $value) {
            //            echo 'key:'.$key.'~~~value:'.$value.'</br>';
            //            $value=json_decode($value);
            //            var_dump($value);
            $value['studentSignInType'] = $students[$value->id];
        }

        if (isset($lists) && $lists != '') {

            return $lists;
        }

        return false;
    }
    //{"29":3,"31":3,"35":2,"36":3,"37":3,"38":3,"39":3,"40":3,"41":3,"42":3}
    //统计所有已到学生
    public function getOkStudents($data)
    {
        //单独返回students这个值
        $students = self::where('id', $data['id'])->value('students');

        $students = json_decode($students, true);
        $arr=[];

        if (!empty($students)){
            foreach ($students as $key => $value) {
                if ($value == 3) {
                    array_push($arr,$key);
                }
            };
        }
        else
            return false;
        $student = new SchoolStudent();
        $lists = $student->allStudent($arr);
        foreach ($lists as $key => $value) {
            //            echo 'key:'.$key.'~~~value:'.$value.'</br>';
            //            $value=json_decode($value);
            //            var_dump($value);
            $value['studentSignInType'] = $students[$value->id];
        }

        if (isset($lists) && $lists != '') {

            return $lists;
        }

        return false;
    }

    //选择该教室的点名方式 0:二维码 1:地址位置 3:蓝牙 4:随机
    public function selectSignInType($data)
    {
        $room = self::where('id', $data['id'])->find();
        if (!isset($room)) {
            return false;
        }
        $res = self::allowField(true)->where('id', $data['id'])->update($data);
        if (isset($res) || $res == 1) {
            return true;
        }
        return false;
    }
    //选择该教室的点名方式 0:二维码 1:地址位置 3:蓝牙 4:随机
    //地址位置
    public function roomAddress($data)
    {
        $res = self::allowField(true)->update($data, array('id' => $data['id']));
        //        return $res;
        if (isset($res) && $res != '') {
            return $res;
        }
        return false;
        //        var_dump($res);
        //        die();
    }
    //选择该教室的点名方式 0:二维码 1:地址位置 3:蓝牙 4:随机
    //随机点名
    public function randomStudent($data)
    {
        $res = self::allowField(true)->update($data, array('id' => $data['id']));
        if (isset($res) && $res != '') {
            return $res;
        }
        return false;
    }

    //随机点名 学生签到pass 学生ID 1:迟到 2:旷课  3:正常
    public function students($data, $studentSignInType)
    {
        $students = self::where('id', $data['id'])->value('students');
        //        if (in_array($data['student_id'], json_decode($students['students']))) {
        $students = json_decode($students, true);
        $students[$data['student_id']] = $studentSignInType;
        //        return $students;
        //        die();
        //        }
        $students = array(
            'students' => $students
        );
        $res = self::where('id', $data['id'])->update($students);
        //签到功
        if ($res == 1) {
            $students = self::where('id', $data['id'])->find();
            return $students;
        }
        //        if (in_array($data['student_id'],$students)){
        //            return false;
        //        }
        //        array_push($students,$data['student_id']);
        //        $res=self::where('id',$data['id'])->update($data);
        return false;
    }
    //二维码点名
    public function qrcodeSignIn($data, $studentSignInType)
    {
        $students = self::where('id', $data['id'])->value('students');
        //        if (in_array($data['student_id'], json_decode($students['students']))) {
        $students = json_decode($students, true);
        $students[$data['sign_in_type']] = $studentSignInType;
        //        return $students;
        //        die();
        //        }
        $students = array(
            'students' => $students
        );
        $res = self::where('id', $data['id'])->update($students);
        //签到功
        if ($res == 1) {
            $students = self::where('id', $data['id'])->find();
            return $students;
        }
        //        if (in_array($data['student_id'],$students)){
        //            return false;
        //        }
        //        array_push($students,$data['student_id']);
        //        $res=self::where('id',$data['id'])->update($data);
        return false;
    }


    //搜索教室
    public function searchRoom($data)
    {
        $res = self::where('room_id', 'like', '%' . $data['room_id'] . '%')->select();
        if (isset($res) && !($res->isEmpty())) {
            # code...
            return $res;
        }
        return false;
    }

    //获取教室的签到类型
    public function getRoomType($data)
    {
        $res = self::where('id', $data['id'])->find();
        if (isset($res)) {
            return $res;
        }
        return false;
    }


}