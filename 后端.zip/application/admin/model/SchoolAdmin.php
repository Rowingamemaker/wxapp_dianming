<?php
/**
 * Created by PhpStorm.
 * Students: Rowin
 * Date: 2018/5/4
 * Time: 3:03
 */

namespace app\admin\model;


use think\Model;

class SchoolAdmin extends Model
{
    protected $autoWriteTimestamp=true;
    //登陆校验
    public function checkoutAdmin($data){
        $res=self::where('admin_username',$data['admin_username'])->find();
//        var_dump($res);
//        die();
        if ($res['admin_password']==$data['admin_password']){
            return true;
        }
        return false;
    }
    public  function changeAdmin($data){
        $res=self::where('admin_username',$data['admin_username'])->find();
        if (isset($res)){
            $result=$res->where('admin_username',$data['admin_username'])->update(array(
                'admin_password'=>$data['admin_password']
            ));
            if ($result==1){
                return true;
            }
        }
        return false;
    }

}