<?php
/**
 * Created by PhpStorm.
 * Students: Rowin
 * Date: 2018/5/4
 * Time: 6:38
 */

namespace app\admin\model;


use think\Model;

class SchoolSignin extends Model
{
    protected $autoWriteTimestamp=true;
    //记录添加
    public function signInAdd($data){
        $res=self::allowField(true)->save($data);
        if ($res==1){
            //添加成功
            return true;
        }
        return false;
    }
    //记录查找
    public  function signInSelect(){
        //分页查询
        $list=self::paginate(10);
        return $list;
    }
    //地理位置添加
    public function signIn($data){
        $where=array(
            'room_id'=>$data['room_id'],
            'student_id'=>$data['student_id']
        );
        //查找是否有签到记录
        $signIn=self::allowField(true)->where($where)->find();
        //如果没有则添加  有则更新
        if (!isset($signIn)){
            //添加
            $res=self::allowField(true)->save($data);
            if ($res==1){
                return true;
            }
        }else{
            //isUpdate  表示这个是更新操作
            $res=$signIn->allowField(true)->isUpdate(true)->save($data);
            if ($res==1){
                return true;
            }
        }
        return false;
    }
}