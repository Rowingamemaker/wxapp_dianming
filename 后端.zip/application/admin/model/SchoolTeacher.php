<?php
/**
 * Created by PhpStorm.
 * Students: Rowin
 * Date: 2018/5/4
 * Time: 23:41
 */

namespace app\admin\model;


use think\Model;

class SchoolTeacher extends Model
{
    protected $autoWriteTimestamp=true;
    //获取所有老师
    public function getAllTeachers(){
        $res=self::paginate(10);
        if (!empty($res)){
            return $res;
        }
        return false;
    }
    public function delTeacher($id){
        $res=self::where('id',$id)->delete();
        if ($res){
            return true;
        }
        return false;
    }
    //查找老师
    public function getTeacher($id){
        $res=self::where('id',$id)->value('teacher_name');
        if (isset($res))
            return $res;
        return '0.0';
    }
    //对面数据库 是否有open_id存在
    public function wxLogin($data)
    {
        $user = self::where('open_id', $data['open_id'])->find();
        $res='';
        if (isset($user)) {
            //更新
            $res = $user->where('id',$user->id)->update($data);
        }else{
            //插入
            $res = self::allowField(true)->save($data);
        }
        if ($res == 1) {
            //添加成功
            return true;
        }
        return false;
    }
    //查找出该用户id
    public function userId($token)
    {
        $token = self::where('open_id', $token)->find();
        if (isset($token)) {
            return $token->id;
        }
        return false;
    }

}