<?php
/**
 * Created by PhpStorm.
 * Students: Rowin
 * Date: 2018/5/6
 * Time: 0:06
 */

namespace app\admin\model;


use think\Model;

class SchoolStudent extends Model
{
    protected $autoWriteTimestamp = true;

    //获取所有学生
    public function getAllStudents()
    {
        $res = self::paginate(10);
        if (!empty($res)) {
            return $res;
        }
        return false;
    }

    //传入数组返回总学生
    public function allStudent($data)
    {
            $res=SchoolStudent::all($data);
            return $res;
    }

    public function delStudents($id)
    {
        $res = self::where('id', $id)->delete();
        if ($res) {
            return true;
        }
        return false;
    }

    //对面数据库 是否有open_id存在
    public function wxLogin($data)
    {
        $user = self::where('open_id', $data['open_id'])->find();
        $res = '';
        if (isset($user)) {
            //更新
            $res = $user->allowField(true)->where('id', $user->id)->data($data)->update();
        } else {
            //插入
            $res = self::allowField(true)->save($data);
        }
        if ($res == 1) {
            //添加成功
            return true;
        }
        return false;
    }

    //查找出该用户id
    public function userId($token)
    {
        $token = self::where('open_id', $token)->find();
        if (isset($token)) {
            return $token->id;
        }
        return false;
    }
    //通过学生id 找出

}